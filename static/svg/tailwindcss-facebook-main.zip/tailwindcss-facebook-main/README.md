# TailwindCSS Facebook Responsive UI and Dark Mode

Make Facebook Home Page with Responsive and Dark Mode using TailwindCSS

## Video

https://youtu.be/FzJkNtixGuQ

!["TailwindCSS Facebook Responsive UI"](https://user-images.githubusercontent.com/67447840/107171905-81791700-69f6-11eb-8024-5ff5fc74a12e.png "TailwindCSS Facebook Responsive UI")
